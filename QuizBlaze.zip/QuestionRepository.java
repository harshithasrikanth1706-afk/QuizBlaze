package com.quiz.repository;

import com.quiz.model.Question;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface QuestionRepository extends MongoRepository<Question, String> {

    // Find all questions by topic
    List<Question> findByTopic(String topic);

    // Find questions by topic and difficulty
    List<Question> findByTopicAndDifficulty(String topic, String difficulty);

    // Count by topic
    long countByTopic(String topic);

    // Random sample — handled in service via aggregation
    @Query("{ 'topic': ?0, 'difficulty': ?1 }")
    List<Question> findByTopicAndDifficultyIn(String topic, String difficulty);
}
