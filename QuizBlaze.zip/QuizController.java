package com.quiz.controller;

import com.quiz.model.Question;
import com.quiz.model.ScoreEntry;
import com.quiz.service.QuizService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")   // Allow frontend on any port during development
public class QuizController {

    @Autowired
    private QuizService quizService;

    // ──────────────────────────────
    // GET /api/topics
    // Returns distinct topic names stored in MongoDB
    // ──────────────────────────────
    @GetMapping("/topics")
    public ResponseEntity<List<String>> getTopics() {
        return ResponseEntity.ok(quizService.getTopics());
    }

    // ──────────────────────────────
    // GET /api/questions?topic=science&difficulty=easy&count=10
    // Returns random questions for the given topic + difficulty
    // ──────────────────────────────
    @GetMapping("/questions")
    public ResponseEntity<?> getQuestions(
            @RequestParam String topic,
            @RequestParam(defaultValue = "easy") String difficulty,
            @RequestParam(defaultValue = "10") int count) {

        if (count < 1 || count > 50) {
            return ResponseEntity.badRequest()
                .body(Map.of("error", "count must be between 1 and 50"));
        }

        List<Question> questions = quizService.getRandomQuestions(topic, difficulty, count);
        if (questions.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(questions);
    }

    // ──────────────────────────────
    // POST /api/leaderboard
    // Body: { name, topic, score, time, correct, total }
    // Saves score to MongoDB and returns the saved entry
    // ──────────────────────────────
    @PostMapping("/leaderboard")
    public ResponseEntity<ScoreEntry> saveScore(@RequestBody ScoreEntry entry) {
        ScoreEntry saved = quizService.saveScore(entry);
        return ResponseEntity.ok(saved);
    }

    // ──────────────────────────────
    // GET /api/leaderboard
    // Returns global top-10 scores
    // ──────────────────────────────
    @GetMapping("/leaderboard")
    public ResponseEntity<List<ScoreEntry>> getLeaderboard() {
        return ResponseEntity.ok(quizService.getLeaderboard());
    }

    // ──────────────────────────────
    // GET /api/leaderboard/{topic}
    // Returns top scores for a specific topic
    // ──────────────────────────────
    @GetMapping("/leaderboard/{topic}")
    public ResponseEntity<List<ScoreEntry>> getTopicLeaderboard(@PathVariable String topic) {
        return ResponseEntity.ok(quizService.getTopicLeaderboard(topic));
    }

    // ──────────────────────────────
    // POST /api/seed
    // Seed the database with sample questions (dev use only)
    // ──────────────────────────────
    @PostMapping("/seed")
    public ResponseEntity<String> seed() {
        quizService.seedIfEmpty();
        return ResponseEntity.ok("Database seeded successfully.");
    }

    // ──────────────────────────────
    // GET /api/health
    // ──────────────────────────────
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of("status", "UP", "service", "QuizBlaze API"));
    }
}
