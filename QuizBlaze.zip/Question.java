package com.quiz.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.List;

@Document(collection = "questions")
public class Question {

    @Id
    private String id;
    private String topic;
    private String difficulty;     // easy | medium | hard
    private String question;
    private List<String> options;
    private int correctIndex;
    private String explanation;

    // ─── Constructors ───
    public Question() {}

    public Question(String topic, String difficulty, String question,
                    List<String> options, int correctIndex, String explanation) {
        this.topic        = topic;
        this.difficulty   = difficulty;
        this.question     = question;
        this.options      = options;
        this.correctIndex = correctIndex;
        this.explanation  = explanation;
    }

    // ─── Getters & Setters ───
    public String getId()              { return id; }
    public void   setId(String id)    { this.id = id; }

    public String getTopic()                { return topic; }
    public void   setTopic(String topic)   { this.topic = topic; }

    public String getDifficulty()                   { return difficulty; }
    public void   setDifficulty(String difficulty) { this.difficulty = difficulty; }

    public String getQuestion()                   { return question; }
    public void   setQuestion(String question)   { this.question = question; }

    public List<String> getOptions()                    { return options; }
    public void         setOptions(List<String> opts)  { this.options = opts; }

    public int  getCorrectIndex()             { return correctIndex; }
    public void setCorrectIndex(int ci)       { this.correctIndex = ci; }

    public String getExplanation()                       { return explanation; }
    public void   setExplanation(String e)              { this.explanation = e; }
}
