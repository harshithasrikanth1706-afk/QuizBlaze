package com.quiz.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDateTime;

@Document(collection = "scores")
public class ScoreEntry {

    @Id
    private String id;
    private String name;
    private String topic;
    private int    score;        // percentage 0–100
    private int    time;         // seconds
    private int    correct;
    private int    total;
    private LocalDateTime createdAt;

    public ScoreEntry() {
        this.createdAt = LocalDateTime.now();
    }

    // Getters & Setters
    public String getId()              { return id; }
    public void   setId(String id)    { this.id = id; }

    public String getName()              { return name; }
    public void   setName(String n)    { this.name = n; }

    public String getTopic()              { return topic; }
    public void   setTopic(String t)    { this.topic = t; }

    public int  getScore()           { return score; }
    public void setScore(int s)      { this.score = s; }

    public int  getTime()           { return time; }
    public void setTime(int t)      { this.time = t; }

    public int  getCorrect()          { return correct; }
    public void setCorrect(int c)    { this.correct = c; }

    public int  getTotal()          { return total; }
    public void setTotal(int t)    { this.total = t; }

    public LocalDateTime getCreatedAt()                      { return createdAt; }
    public void          setCreatedAt(LocalDateTime dt)     { this.createdAt = dt; }
}
