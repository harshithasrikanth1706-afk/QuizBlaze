# QuizBlaze — Interactive Quiz System

**Stack:** HTML · CSS · JavaScript (Frontend) + Java Spring Boot (Backend) + MongoDB (Database)

---

## Project Structure

```
quiz-system/
├── frontend/
│   └── index.html          ← Complete quiz web app (open directly in browser)
└── backend/
    ├── pom.xml             ← Maven dependencies
    ├── seed.js             ← MongoDB seed script
    └── src/main/java/com/quiz/
        ├── QuizApplication.java
        ├── controller/QuizController.java
        ├── model/Question.java
        ├── model/ScoreEntry.java
        ├── repository/QuestionRepository.java
        ├── repository/ScoreRepository.java
        └── service/QuizService.java
```

---

## Quick Start (Frontend Only — No Backend Needed)

1. Open `frontend/index.html` in any browser
2. Select a topic, difficulty, and question count
3. Click **Start Quiz** and play!

Scores are saved to localStorage automatically.

---

## Full Stack Setup (Java + MongoDB)

### Step 1 — Install MongoDB

**Local:**
```bash
# macOS
brew tap mongodb/brew && brew install mongodb-community
brew services start mongodb-community

# Ubuntu/Debian
sudo apt-get install -y mongodb
sudo systemctl start mongodb

# Windows — download from https://www.mongodb.com/try/download/community
```

**Cloud (MongoDB Atlas):**
1. Create a free cluster at https://cloud.mongodb.com
2. Copy your connection string
3. Update `backend/src/main/resources/application.properties`

---

### Step 2 — Seed the Database

```bash
cd backend

# With local MongoDB:
mongosh quizblaze seed.js

# With MongoDB Atlas:
mongosh "mongodb+srv://<user>:<pass>@<cluster>.mongodb.net" seed.js
```

---

### Step 3 — Run the Java Backend

**Prerequisites:** Java 17+, Maven 3.8+

```bash
cd backend
mvn spring-boot:run
```

The API will start at `http://localhost:8080`

**Verify it's running:**
```bash
curl http://localhost:8080/api/health
# → {"status":"UP","service":"QuizBlaze API"}
```

---

### Step 4 — Connect Frontend to Backend

Open `frontend/index.html` and change line:

```js
const USE_BACKEND = false;  // Change to: true
```

Now questions will be fetched from MongoDB via the Java API.

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Health check |
| GET | `/api/topics` | List all topics |
| GET | `/api/questions?topic=science&difficulty=easy&count=10` | Get random questions |
| GET | `/api/leaderboard` | Global top-10 |
| GET | `/api/leaderboard/{topic}` | Topic leaderboard |
| POST | `/api/leaderboard` | Save a score |
| POST | `/api/seed` | Re-seed questions |

---

## Adding More Questions

Edit `backend/seed.js` and add entries to the `questions` array:

```js
{
  topic: "science",        // science | math | history | technology | geography | sports
  difficulty: "medium",   // easy | medium | hard
  question: "Your question here?",
  options: ["Option A", "Option B", "Option C", "Option D"],
  correctIndex: 0,        // 0-based index of correct option
  explanation: "Why this answer is correct."
}
```

Then re-run:
```bash
mongosh quizblaze seed.js
```

---

## Features

- 6 topics × 3 difficulty levels × 15 questions each
- Timer tracking per quiz session
- Instant answer feedback with correct option highlighting
- Score percentage with animated ring
- Leaderboard (localStorage + optional MongoDB persistence)
- Backend gracefully falls back to built-in questions if offline
- CORS enabled for local development

---

## Tech Stack Details

| Layer | Technology |
|-------|------------|
| Frontend | Vanilla HTML/CSS/JS |
| Fonts | Google Fonts (Inter + Space Grotesk) |
| Backend | Java 17, Spring Boot 3.2 |
| Database | MongoDB 6+ |
| ORM | Spring Data MongoDB |
| Build | Maven 3.8+ |
