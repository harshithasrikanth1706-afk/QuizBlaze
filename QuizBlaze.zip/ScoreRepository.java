package com.quiz.repository;

import com.quiz.model.ScoreEntry;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ScoreRepository extends MongoRepository<ScoreEntry, String> {
    List<ScoreEntry> findTop10ByOrderByScoreDescTimeAsc();
    List<ScoreEntry> findByTopicOrderByScoreDesc(String topic);
}
