package com.quiz.service;

import com.quiz.model.Question;
import com.quiz.model.ScoreEntry;
import com.quiz.repository.QuestionRepository;
import com.quiz.repository.ScoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class QuizService {

    @Autowired
    private QuestionRepository questionRepo;

    @Autowired
    private ScoreRepository scoreRepo;

    @Autowired
    private MongoTemplate mongoTemplate;

    /**
     * Returns `count` random questions for a given topic + difficulty.
     * Uses MongoDB $sample aggregation for true random ordering.
     */
    public List<Question> getRandomQuestions(String topic, String difficulty, int count) {
        Aggregation agg = Aggregation.newAggregation(
            Aggregation.match(
                Criteria.where("topic").is(topic)
                    .and("difficulty").is(difficulty)
            ),
            Aggregation.sample(count)
        );

        AggregationResults<Question> results =
            mongoTemplate.aggregate(agg, "questions", Question.class);

        List<Question> questions = results.getMappedResults();

        // Shuffle options for each question before sending to client
        questions.forEach(this::shuffleOptions);
        return questions;
    }

    /**
     * Randomises the order of a question's options,
     * updating correctIndex to match the new position.
     */
    private void shuffleOptions(Question q) {
        List<String> opts = new ArrayList<>(q.getOptions());
        String correct = opts.get(q.getCorrectIndex());
        Collections.shuffle(opts);
        q.setOptions(opts);
        q.setCorrectIndex(opts.indexOf(correct));
    }

    /** Persist a leaderboard entry. */
    public ScoreEntry saveScore(ScoreEntry entry) {
        return scoreRepo.save(entry);
    }

    /** Top 10 global leaderboard. */
    public List<ScoreEntry> getLeaderboard() {
        return scoreRepo.findTop10ByOrderByScoreDescTimeAsc();
    }

    /** Topic-specific leaderboard. */
    public List<ScoreEntry> getTopicLeaderboard(String topic) {
        return scoreRepo.findByTopicOrderByScoreDesc(topic);
    }

    /** All topics available in DB. */
    public List<String> getTopics() {
        return mongoTemplate.findDistinct("topic", "questions",
            Question.class, String.class);
    }

    /** Seed database with sample questions (call once on startup if empty). */
    public void seedIfEmpty() {
        if (questionRepo.count() > 0) return;

        List<Question> seed = List.of(
            new Question("science", "easy",
                "What is the chemical symbol for water?",
                List.of("H2O", "CO2", "NaCl", "O2"), 0,
                "Water is made of two hydrogen and one oxygen atom."),

            new Question("science", "medium",
                "What is the speed of light in a vacuum?",
                List.of("3×10⁶ m/s", "3×10⁸ m/s", "3×10¹⁰ m/s", "3×10⁴ m/s"), 1,
                "Light travels at approximately 299,792,458 m/s in a vacuum."),

            new Question("math", "easy",
                "What is 7 × 8?",
                List.of("54", "56", "58", "62"), 1,
                "7 multiplied by 8 equals 56."),

            new Question("technology", "easy",
                "What does HTML stand for?",
                List.of("HyperText Markup Language", "HighText Machine Language",
                        "HyperText Machine Learning", "HyperTool Markup Language"), 0,
                "HTML is the standard markup language for creating web pages.")
        );

        questionRepo.saveAll(seed);
    }
}
