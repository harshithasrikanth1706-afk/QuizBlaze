// ═══════════════════════════════════════════
//  QuizBlaze — MongoDB Seed Script
//  Run with: mongosh quizblaze seed.js
//  OR: mongosh "mongodb+srv://..." seed.js
// ═══════════════════════════════════════════

db = db.getSiblingDB('quizblaze');

// Clear existing questions (optional — comment out to append)
db.questions.drop();
db.scores.drop();

print("Seeding QuizBlaze questions...");

const questions = [
  // ─── SCIENCE ───────────────────────────────
  { topic:"science", difficulty:"easy",   question:"What is the chemical symbol for water?",          options:["H2O","CO2","NaCl","O2"],                           correctIndex:0, explanation:"Water = 2 hydrogen + 1 oxygen." },
  { topic:"science", difficulty:"easy",   question:"Which planet is known as the Red Planet?",        options:["Venus","Mars","Jupiter","Saturn"],                   correctIndex:1, explanation:"Mars appears red due to iron oxide on its surface." },
  { topic:"science", difficulty:"easy",   question:"What is the powerhouse of the cell?",             options:["Nucleus","Ribosome","Mitochondria","Golgi body"],    correctIndex:2, explanation:"Mitochondria generate ATP energy for the cell." },
  { topic:"science", difficulty:"easy",   question:"What gas do plants absorb during photosynthesis?",options:["Oxygen","Nitrogen","Carbon Dioxide","Hydrogen"],     correctIndex:2, explanation:"Plants use CO₂ + water + light to make glucose." },
  { topic:"science", difficulty:"easy",   question:"Which subatomic particle has no charge?",         options:["Proton","Electron","Neutron","Positron"],            correctIndex:2, explanation:"Neutrons are electrically neutral." },
  { topic:"science", difficulty:"medium", question:"What is the speed of light in a vacuum?",         options:["3×10⁶ m/s","3×10⁸ m/s","3×10¹⁰ m/s","3×10⁴ m/s"],correctIndex:1, explanation:"c ≈ 299,792,458 m/s" },
  { topic:"science", difficulty:"medium", question:"What is the atomic number of carbon?",            options:["4","6","8","12"],                                    correctIndex:1, explanation:"Carbon has 6 protons." },
  { topic:"science", difficulty:"medium", question:"Which organ produces insulin?",                   options:["Liver","Kidney","Heart","Pancreas"],                 correctIndex:3, explanation:"Beta cells in the pancreas produce insulin." },
  { topic:"science", difficulty:"medium", question:"What is Newton's First Law called?",              options:["Law of Gravity","Law of Inertia","Law of Motion","Law of Friction"], correctIndex:1, explanation:"Objects at rest stay at rest unless acted upon." },
  { topic:"science", difficulty:"hard",   question:"What is the half-life of Carbon-14?",            options:["1,000 years","3,500 years","5,730 years","10,000 years"], correctIndex:2, explanation:"C-14 half-life is ~5,730 years, used in radiocarbon dating." },

  // ─── MATH ────────────────────────────────
  { topic:"math", difficulty:"easy",   question:"What is 7 × 8?",                                    options:["54","56","58","62"],                                 correctIndex:1, explanation:"7 × 8 = 56" },
  { topic:"math", difficulty:"easy",   question:"What is the value of π to 2 decimal places?",      options:["3.12","3.14","3.16","3.18"],                         correctIndex:1, explanation:"π ≈ 3.14159..." },
  { topic:"math", difficulty:"easy",   question:"Solve: 2x + 5 = 13. What is x?",                  options:["3","4","5","6"],                                     correctIndex:1, explanation:"2x = 8, so x = 4." },
  { topic:"math", difficulty:"easy",   question:"What is the square root of 144?",                  options:["10","11","12","13"],                                 correctIndex:2, explanation:"12 × 12 = 144" },
  { topic:"math", difficulty:"medium", question:"What is the derivative of x²?",                    options:["x","2x","x/2","2"],                                  correctIndex:1, explanation:"Power rule: d/dx(xⁿ) = nxⁿ⁻¹" },
  { topic:"math", difficulty:"medium", question:"What is log₁₀(1000)?",                             options:["2","3","4","5"],                                     correctIndex:1, explanation:"10³ = 1000, so log₁₀(1000) = 3" },
  { topic:"math", difficulty:"hard",   question:"What is the integral of 2x dx?",                  options:["x","x²+C","2x²+C","x+C"],                           correctIndex:1, explanation:"∫2x dx = x² + C" },
  { topic:"math", difficulty:"hard",   question:"Find the determinant of [[2,3],[1,4]]",            options:["5","8","11","14"],                                   correctIndex:0, explanation:"det = (2×4) − (3×1) = 8 − 3 = 5" },

  // ─── TECHNOLOGY ──────────────────────────
  { topic:"technology", difficulty:"easy",   question:"What does HTML stand for?",                  options:["HyperText Markup Language","HighText Machine Language","HyperText Machine Learning","HyperTool Markup Language"], correctIndex:0, explanation:"HTML defines the structure of web pages." },
  { topic:"technology", difficulty:"easy",   question:"What does CPU stand for?",                   options:["Central Processing Unit","Computer Personal Unit","Core Processing Utility","Central Program Unit"], correctIndex:0, explanation:"The CPU is the brain of a computer." },
  { topic:"technology", difficulty:"easy",   question:"What does RAM stand for?",                   options:["Random Access Memory","Rapid Access Module","Read-only Access Memory","Remote Access Module"], correctIndex:0, explanation:"RAM is fast, volatile working memory." },
  { topic:"technology", difficulty:"medium", question:"What is the binary value of decimal 10?",    options:["1000","1001","1010","1100"],                         correctIndex:2, explanation:"8+2=10 in binary is 1010." },
  { topic:"technology", difficulty:"medium", question:"Which data structure follows LIFO order?",   options:["Queue","Array","Stack","Linked List"],               correctIndex:2, explanation:"Stack = Last In First Out." },
  { topic:"technology", difficulty:"medium", question:"What protocol is used to send emails?",      options:["HTTP","FTP","SMTP","SSH"],                           correctIndex:2, explanation:"SMTP = Simple Mail Transfer Protocol." },
  { topic:"technology", difficulty:"hard",   question:"What is O(n log n) typically associated with?", options:["Bubble sort","Insertion sort","Merge sort","Selection sort"], correctIndex:2, explanation:"Merge sort has O(n log n) time complexity." },

  // ─── HISTORY ─────────────────────────────
  { topic:"history", difficulty:"easy",   question:"In which year did World War II end?",            options:["1943","1944","1945","1946"],                         correctIndex:2, explanation:"WWII ended in 1945 with Germany (May) and Japan (September) surrendering." },
  { topic:"history", difficulty:"easy",   question:"Who was the first President of the United States?", options:["John Adams","Thomas Jefferson","George Washington","James Madison"], correctIndex:2, explanation:"George Washington served 1789–1797." },
  { topic:"history", difficulty:"easy",   question:"When did the French Revolution begin?",          options:["1776","1789","1799","1804"],                         correctIndex:1, explanation:"The storming of the Bastille occurred on July 14, 1789." },
  { topic:"history", difficulty:"medium", question:"The Magna Carta was signed in which year?",      options:["1215","1315","1415","1515"],                         correctIndex:0, explanation:"King John signed Magna Carta in 1215 at Runnymede." },
  { topic:"history", difficulty:"medium", question:"The Battle of Waterloo was fought in?",         options:["1805","1810","1815","1820"],                         correctIndex:2, explanation:"Napoleon was defeated at Waterloo on June 18, 1815." },
  { topic:"history", difficulty:"hard",   question:"Which country was first to grant women the right to vote?", options:["USA","France","New Zealand","UK"], correctIndex:2, explanation:"New Zealand granted women's suffrage in 1893." },

  // ─── GEOGRAPHY ───────────────────────────
  { topic:"geography", difficulty:"easy",   question:"What is the capital of Australia?",           options:["Sydney","Melbourne","Canberra","Brisbane"],          correctIndex:2, explanation:"Canberra has been Australia's capital since 1913." },
  { topic:"geography", difficulty:"easy",   question:"Which is the longest river in the world?",    options:["Amazon","Mississippi","Nile","Yangtze"],             correctIndex:2, explanation:"The Nile stretches ~6,650 km." },
  { topic:"geography", difficulty:"easy",   question:"What is the smallest country in the world?",  options:["Monaco","Liechtenstein","Vatican City","San Marino"],correctIndex:2, explanation:"Vatican City covers just 0.44 km²." },
  { topic:"geography", difficulty:"medium", question:"Which country has the most natural lakes?",   options:["Russia","USA","Brazil","Canada"],                    correctIndex:3, explanation:"Canada has over 2 million lakes." },
  { topic:"geography", difficulty:"hard",   question:"Which is the world's largest desert?",        options:["Sahara","Gobi","Arabian","Antarctic"],               correctIndex:3, explanation:"Antarctica is classified as a cold desert — 14.2 million km²." },

  // ─── SPORTS ──────────────────────────────
  { topic:"sports", difficulty:"easy",   question:"How many players in a basketball team on court?", options:["4","5","6","7"],                                    correctIndex:1, explanation:"Each team fields 5 players on court." },
  { topic:"sports", difficulty:"easy",   question:"How many Grand Slam tournaments are there?",     options:["2","3","4","5"],                                     correctIndex:2, explanation:"Australian, French, Wimbledon, US Open." },
  { topic:"sports", difficulty:"easy",   question:"How long is a marathon?",                        options:["26.2 km","40 km","42.195 km","50 km"],              correctIndex:2, explanation:"Official marathon distance is 42.195 km." },
  { topic:"sports", difficulty:"easy",   question:"Which country has won the most FIFA World Cups?", options:["Germany","Argentina","Italy","Brazil"],             correctIndex:3, explanation:"Brazil has won 5 World Cups." },
  { topic:"sports", difficulty:"medium", question:"In cricket, how many balls in an over?",         options:["4","6","8","10"],                                    correctIndex:1, explanation:"An over consists of 6 legal deliveries." },
  { topic:"sports", difficulty:"hard",   question:"What is the diameter of a basketball hoop in inches?", options:["16","18","20","22"],                         correctIndex:1, explanation:"NBA regulation hoop diameter is 18 inches." },
];

db.questions.insertMany(questions);

// Create useful indexes
db.questions.createIndex({ topic: 1, difficulty: 1 });
db.scores.createIndex({ score: -1, time: 1 });

print(`✅ Inserted ${questions.length} questions into quizblaze.questions`);
print("✅ Indexes created");
print("🚀 Database ready — start the Spring Boot backend!");
